from pickle import TRUE
from pydoc import doc
from rest_framework import serializers
from .models import Customer, Datasheet, Document, Profession


class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = (
            'id', 'dtype', 'doc_number', 'customer'
            )

class DocumentSerializerCreate(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = (
            'id', 'dtype', 'doc_number', 'customer'
            )
        #metto senno chiede id di costumer che ancora non esiste 
        read_only_fields = ['customer']

class DatasheetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Datasheet
        fields = ['id','description', 'historical_data']


class ProfessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profession
        fields = ['id','description']

# Serializers define the API representation.
class CustomerSerializer(serializers.ModelSerializer):
    #cosi dichiaro tpo un metodo statico, devo per forza creare un metodo num_serializers con get_ davanti
    num_professions = serializers.SerializerMethodField()
    #ora mi dara il nome del datasheet, non più il suo id
    #data_sheet = serializers.SerializerMethodField()
    #per id
    #data_sheet = serializers.PrimaryKeyRelatedField(read_only='True')
    #dico a django che voglio che me lo serializzi con il metodo sopra
    data_sheet = DatasheetSerializer()#(read_only=True)
    #professions = serializers.StringRelatedField(many=True)
    professions = ProfessionSerializer(many=True)
    #doc = serializers.StringRelatedField()
    doc = DocumentSerializerCreate(many=True)

    class Meta:
        model = Customer
        fields = ['id','name','address','professions','data_sheet', 'doc', 'active', 'status_message', 'num_professions' ]
    
    def create(self, validated_data):
        #profession------------------------------------
        professions = validated_data['professions']
        del validated_data['professions']  #per eliminare

        #doc------------------------------------
        documents = validated_data['doc']
        del validated_data['doc']

        data_sheet = validated_data['data_sheet']
        del validated_data['data_sheet']  #per eliminare

        d_sheet = Datasheet.objects.create(**data_sheet)
        customer = Customer.objects.create(**validated_data)
        customer.data_sheet = d_sheet

        for d in documents:
            Document.objects.create(
                dtype=d['dtype'],
                doc_number=d['doc_number'],
                customer_id = customer.id
            )

        #creo lavori da attacare al customer(manytomany)
        for profession in professions:
            prof = Profession.objects.create(**profession)
            customer.professions.add(prof)

        customer.save()
        return customer
    

    def get_num_professions(self, obj):
        return obj.num_professions()
    
   # def get_data_sheet(self, obj):
        return obj.data_sheet.description

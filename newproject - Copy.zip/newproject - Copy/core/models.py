from pydoc import Doc
from tkinter import CASCADE
from django.db import models

# Create your models here.
class Profession(models.Model):
    description = models.CharField(max_length=120)

    def __str__(self):
        return self.description

class Datasheet(models.Model):
    description = models.CharField(max_length=120)
    historical_data = models.TextField()

    def __str__(self):
        return self.description


class Customer(models.Model):
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=50)
    professions = models.ManyToManyField(Profession)
    data_sheet = models.OneToOneField(Datasheet, on_delete=models.CASCADE, null=True, blank=True)
    active = models.BooleanField(default=True)
    #non mette doc?
    doc = models.TextField(max_length=12, unique=True, null=True, blank=True)

    #per avere una stringa al posto di T/F in active
    @property
    def status_message(self):
        if self.active == True:
            return 'Customer active'
        else:
            return 'Customer not active'
    #numero di lavori 
    def num_professions(self):
        return self.professions.all().count()

    def __str__(self):
        return self.name


class Document(models.Model):
    # PP = 'PP'
    # ID = 'ID'
    # OT = 'OT'

    # DOC_TYPES = (
    #     (PP, 'Passport'),
    #     (ID, 'Identity Card'),
    #     (OT, 'Others')
    # )

    dtype = models.CharField(max_length=50) # models.CharField(choices=DOC_TYPES, max_length=2)
    doc_number = models.CharField(max_length=50)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)

    def __str__(self):
        return self.doc_number
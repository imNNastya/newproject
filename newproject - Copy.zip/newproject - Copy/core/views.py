
from unicodedata import name
from urllib import request
from django.http import HttpResponseNotAllowed
from .models import Customer, Datasheet, Document, Profession
from .serializers import CustomerSerializer, ProfessionSerializer, DatasheetSerializer, DocumentSerializer
from rest_framework import viewsets 
from rest_framework.response import Response
from django.shortcuts import render
from rest_framework.decorators import action
from django.db import transaction
from rest_framework import filters
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import AllowAny, IsAdminUser, IsAuthenticatedOrReadOnly, DjangoModelPermissions, DjangoModelPermissionsOrAnonReadOnly


# ViewSets define the view behavior.
class CustomerViewSet(viewsets.ModelViewSet):
    serializer_class = CustomerSerializer
    #inserisco il filtro
    filterset_fields = ['name']
    #inserisco la barra di ricerca; stranamente funziona senza il djagofilterbackend lol 
    filter_backends = [SearchFilter, OrderingFilter]
    filter_fields = ['name']
    search_fields = ['name', 'address', 'data_sheet__description']
    #ordering_fields = ['name', 'id']
    #cosi do la possibilita' di cercare per qualsiasi field(se sche e sicuro)
    ordering_fields = '__all__'
    #setto l'ordine di default se cliente non ci passa nulla
    ordering = ('id')
    lookup_field = ('name')

    authentication_classes = (TokenAuthentication,)

    #filtra per customer 
    def get_queryset(self):
        print('--- GETQUERYSET')
        #import pdb; pdb.set_trace() #per creare breakpoint
        #id = self.request.query_params.get('id', None)
        address = self.request.query_params.get('address', None)
        status = False if self.request.query_params.get('active') == 'False' else True   
        
        print('--- status {}'.format(status))
        if address:
             #__icontains è una funzione che ti dice se la stringa continene la stringa passata
             customers = Customer.objects.filter(address__icontains=address, active=status)
        else :
             customers = Customer.objects.filter(active=status)

        return customers
    #-----------------------------------------------------------
    #def list(self, request, *args, **kwargs):
       #import pdb; pdb.set_trace()
       #customers = Customer.objects.all()
        customers = self.get_queryset()
        serializer = CustomerSerializer(customers, many = True)
        return Response(serializer.data)  
    #-----------------------------------------------------------
    #retrive 
    def retrieve(self, request, *args, **kwargs):
        print('--- RETRIEVE')
        customer = self.get_object()
        serializer =CustomerSerializer(customer)
        return Response(serializer.data)
        #return HttpResponseNotAllowed('Not allowed')  
    #post ----------------------------------------------------------
    # @transaction.atomic
    #def create(self, request, *args, **kwargs):
        data = request.data
        #creo oggetto temp per datasheet sennò da errore quando lo passo in customer create
        ds = Datasheet.objects.create(
            description = 'TEST', historical_data = 'historical_data'
        )

        customer = Customer.objects.create(
            name = data.get['name'], address = data.get['address'], data_sheet = ds
        )

        profession = Profession.objects.filter(id__in=data.get('profession'))
        #print('proffff {}'.format(profession))
        
        for p in profession:
            print('p {}'.format(p))
            customer.professions.add(p)
        customer.save()

        serializer = CustomerSerializer(customer)
        return Response(serializer.data) 
   #--------------------------------------------------------------------   
    #put
    def update(self, request, *args, **kwargs):
        customer = self.get_object()
        data = request.data
        customer.name = data['name']
        customer.address = data['address']
        customer.data_sheet_id = data['data_sheet']

        profession = Profession.objects.filter(id__in=data.get('profession'))
        #profession = Profession.objects.get(id=data['profession'])

        for p in customer.professions.all():
            customer.profession.remove(p)

        customer.professions.add(profession)
        customer.save()

        serializer = CustomerSerializer(customer)
        return Response(serializer.data)
    #patch
    def partial_update(self, request, *args, **kwargs):
        customer = self.get_object()
        #qua mettiamo due cose perche non sappiamo se passera o meno il nome
        customer.name = request.data.get('name', customer.name)
        customer.address = request.data.get('address', customer.address)
        customer.data_sheet_id = request.data.get('data_sheet', customer.data_sheet_id)

        customer.save()
    #delete
    def destroy(self, request, *args, **kwargs):
        customer = self.get_object()
        customer.delete()

        return Response('Object removed')

    @action(detail=True)
    def deactivate(self, request, **kwargs):
        customer = self.get_object()
        customer.active = False

        serializer = CustomerSerializer(customer)
        return Response(serializer.data)
        
    @action(detail=False)
    def deactivateall(self, request, **kwargs):
        #customers = Customer.objects.all()
        customers = self.get_queryset()
        customers.update(active=False)

        serializer = CustomerSerializer(customers, many=True)
        return Response(serializer.data)

    @action(detail=False)
    def activateall(self, request, **kwargs):
       #customers = Customer.objects.all()
        customers = self.get_queryset()
        customers.update(active=True)

        serializer = CustomerSerializer(customers, many=True)
        return Response(serializer.data)

    #!?!?
    @action(detail=False, methods=['POST'])
    def change_status(self, request, **kwargs):

        status = True if request.data['active'] == 'True' else False 
        customers = self.get_queryset()
        customers.update(active=status)
        
        serializer = CustomerSerializer(customers, many=True)
        return Response(serializer.data)
        
        #if self.request.query_params.get('active') == 'True':
         #   status = True
        #else:
         #   status = False

        #status = self.request.query_params.get('active', True)
        #status = True if self.request.query_params['active'] == 'True' else False
        #status = True if reques.data['active'] == 'True' else False

        #customers = self.get_queryset() 
        
        #customers.update(active=status)

        #serializer = CustomerSerializer(customers, many=True)
        #return Response(serializer.data)
               
class ProfessionViewSet(viewsets.ModelViewSet):
    queryset = Profession.objects.all()
    serializer_class = ProfessionSerializer
    authentication_classes = [TokenAuthentication,]
    permission_classes = [IsAdminUser,]



class DatasheetViewSet(viewsets.ModelViewSet):
    queryset = Datasheet.objects.all()
    serializer_class = DatasheetSerializer
    permission_classes = [AllowAny,]


class DocumentViewSet(viewsets.ModelViewSet):
    queryset = Document.objects.all()
    serializer_class = DocumentSerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [DjangoModelPermissions,]

# Create your views here.
